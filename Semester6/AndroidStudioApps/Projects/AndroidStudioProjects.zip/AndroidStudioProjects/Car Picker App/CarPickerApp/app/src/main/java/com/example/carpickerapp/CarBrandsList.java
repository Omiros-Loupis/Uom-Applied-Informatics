package com.example.carpickerapp;

import java.util.ArrayList;
import java.util.List;

public class CarBrandsList {
    private final List<Brand> brandsList = new ArrayList<>();

    public CarBrandsList() {

    }

    public void addBrand(Brand brand) {
        brandsList.add(brand);
    }

    public void addModelToBrand(String name, String model) {
        for (Brand brand : brandsList)
            if (brand.getName().equals(name))
                brand.addModel(model);
    }

    public List<String> getAllBrandNames() {
        List<String> brands = new ArrayList<>();
        for (Brand brand : brandsList)
            brands.add(brand.getName());
        return brands;
    }

    public List<String> getModelsOfBrand(String name) {
        for (Brand brand: brandsList)
            if (brand.getName().equals(name))
                return brand.getModels();
        return null;
    }
}