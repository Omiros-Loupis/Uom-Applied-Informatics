package com.example.carpickerapp;

import java.util.ArrayList;
import java.util.List;

public class Brand {

    private final String name;
    private final List<String> modelsList;

    public Brand(String name) {
        this.name = name;
        modelsList = new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    public List<String> getModels() {
        return modelsList;
    }

    public void addModel(String model) {
        modelsList.add(model);
    }
}