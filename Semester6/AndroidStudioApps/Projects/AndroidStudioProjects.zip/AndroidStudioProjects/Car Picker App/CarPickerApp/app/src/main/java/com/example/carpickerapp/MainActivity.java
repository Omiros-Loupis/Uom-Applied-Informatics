package com.example.carpickerapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;

import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private Spinner dropDown;
    private RadioGroup radioGroup;
    private CarBrandsList brandsList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dropDown = findViewById(R.id.brands_spinner);
        radioGroup = findViewById(R.id.models_radio_group);

        brandsList = new CarBrandsList();

        brandsList.addBrand(new Brand("Tomota"));
        brandsList.addBrand(new Brand("WW"));
        brandsList.addBrand(new Brand("Fissan"));

        brandsList.addModelToBrand("Tomota", "Kauris");
        brandsList.addModelToBrand("Tomota", "Yamis");
        brandsList.addModelToBrand("Tomota", "Gav14");
        brandsList.addModelToBrand("WW", "Molf");
        brandsList.addModelToBrand("WW", "Solo");
    }

    public void onClickPickBrand(View view) {

        String brand = String.valueOf(dropDown.getSelectedItem());
        List<String> modelsList = brandsList.getModelsOfBrand(brand);

        radioGroup.removeAllViews();

        if (modelsList.size() == 0) {
            Toast.makeText(getApplicationContext(),
                    getString(R.string.toast_no_models_text, brand),
                    Toast.LENGTH_SHORT).show();
        } else {
            radioGroup.setOrientation(RadioGroup.VERTICAL);
            createRadioButtons(radioGroup, modelsList);

            radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(RadioGroup rg, int checkedId) {
                    RadioButton rb = findViewById(checkedId);
                    Toast.makeText(getApplicationContext(),
                            brand + " " + rb.getText(),
                            Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    private void createRadioButtons(RadioGroup rg, List<String> modelsList) {

        for (int i = 0; i < modelsList.size(); i++) {
            RadioButton rb = new RadioButton(this);
            rb.setText(modelsList.get(i));
            rb.setId(i + 100);
            rg.addView(rb);
        }
    }
}