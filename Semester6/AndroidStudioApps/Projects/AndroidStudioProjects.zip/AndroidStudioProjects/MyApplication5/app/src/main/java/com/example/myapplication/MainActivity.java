package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    private CarPicker co = new CarPicker();
    public void myOnClickPickBrand(View v) {
        TextView brands = findViewById(R.id.models);
        Spinner color = findViewById(R.id.cars);
        String carMake = String.valueOf(color.getSelectedItem());
        List<String> brandsList = cp.getCars(carMake);
        if (brandsList.size() == 0) {
            brands.setText("There are no models for this brand. Pick another!");
        } else {
            StringBuilder brandsFormatted = new StringBuilder();
            for (String brand : brandsList)
                brandsFormatted.append(brand).append("\n");
            brands.setText(brandsFormatted);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void myOnClickPickBrand(View v){
    }
}