
    public class ComparisonList {
        ArrayList<Comparison> compList = new ArrayList<Comparison>();

        public ComparisonList(String url) {

            try {

                OkHttpHandler okHttpHandler = new OkHttpHandler();
                compList = okHttpHandler.populateDropDown(url);

            } catch (Exception e) {

                e.printStackTrace();
            }
        }

        public ArrayList<Comparison> getList(){
            return compList;
        }

}
