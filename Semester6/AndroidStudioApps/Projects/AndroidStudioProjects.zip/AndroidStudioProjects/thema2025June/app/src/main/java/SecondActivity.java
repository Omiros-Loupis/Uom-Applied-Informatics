public class SecondActivity public class SecondActivity extends AppCompatActivity {


    TextView txt;
    ImageView img;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        Comparison receivedComp = (Comparison) getIntent().getSerializableExtra("comparison");
        Log.d("DEBUG", "Fetched items: " + receivedComp.getImage1());

        txt = findViewById(R.id.textView);
        img = findViewById(R.id.imageView);


        txt.setText(receivedComp.getFullExpression());

        if (receivedComp.checkExpression() == true) {
            Picasso.with(getApplicationContext()).load(Uri.parse(receivedComp.getImage1())).resize(500,
                    500).into(img);
        } else {
            Picasso.with(getApplicationContext()).load(Uri.parse(receivedComp.getImage2())).resize(500,
                    500).into(img);
        }


    }


    public void onClickBack(View view){
        Intent intent = new Intent(SecondActivity.this, MainActivity.class);
        startActivity(intent);
    }
}{
}
