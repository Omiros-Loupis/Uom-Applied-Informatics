
    public class Comparison implements Serializable {

        private int n1;
        private int n2;
        private String image1;
        private String image2;

        public Comparison(int n1,int n2,String image1,String image2){
            this.n1 = n1;
            this.n2 = n2;
            this.image1 = image1;
            this.image2 = image2;
        }

        public int getN1() {
            return n1;
        }

        public int getN2() {
            return n2;
        }

        public String getImage1() {
            return image1;
        }

        public String getImage2() {
            return image2;
        }

        public String getExpression(){
            return n1 + ">" + n2;
        }

        public String getFullExpression(){
            if (n1>n2){
                return getExpression()+" = "+"TRUE";
            }else {
                return getExpression()+" = "+"FALSE";
            }
        }

        public boolean checkExpression(){
            if (n1>n2){
                return true;
            }else
                return false;
        }

    }
