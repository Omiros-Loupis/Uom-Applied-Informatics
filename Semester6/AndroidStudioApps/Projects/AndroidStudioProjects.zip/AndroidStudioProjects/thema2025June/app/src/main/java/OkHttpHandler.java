public class OkHttpHandler {

    public OkHttpHandler() {
        StrictMode.ThreadPolicy policy = new
                StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
    }

    ArrayList<Comparison> populateDropDown(String url) throws Exception {
        ArrayList<Comparison> compList = new ArrayList<>();
        OkHttpClient client = new OkHttpClient().newBuilder().build();
        RequestBody body = RequestBody.create("",
                MediaType.parse("text/plain"));
        Request request = new Request.Builder().url(url).method("POST",
                body).build();
        Response response = client.newCall(request).execute();
        String data = response.body().string();

        try {

            JSONObject json = new JSONObject(data);


            Iterator<String> keys = json.keys();


            while (keys.hasNext()) {
                String key = keys.next();


                JSONObject compObj = json.getJSONObject(key);


                int n1 = compObj.getInt("n1");
                int n2 = compObj.getInt("n2");
                String image1 = compObj.getString("image1");
                String image2 = compObj.getString("image2");


                compList.add(new Comparison(n1, n2, image1, image2));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return compList;

    }
}

