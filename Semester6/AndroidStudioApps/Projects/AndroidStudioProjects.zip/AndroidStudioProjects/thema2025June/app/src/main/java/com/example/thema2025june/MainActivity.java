package com.example.thema2025june;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

    public class MainActivity extends AppCompatActivity {

        String url= "http://egov2.dai.uom.gr/chiron/service.php";
        Button buttonNext;
        Spinner spinner;

        ComparisonList compList;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);

            buttonNext = findViewById(R.id.buttonNext);
            spinner = findViewById(R.id.spinner);

            compList = new ComparisonList(url);

            ArrayList<Comparison> comparisonsList = compList.compList;


            ArrayList<String> expressions = new ArrayList<>();
            for (Comparison comp : comparisonsList) {
                expressions.add(comp.getExpression());
            }


            ArrayAdapter<String> adapter = new ArrayAdapter<>(
                    this, android.R.layout.simple_spinner_item, expressions);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner.setAdapter(adapter);



        }


        public void onClick(View v) {
            Intent intent = new Intent(MainActivity.this, SecondActivity.class);


            int selectedIndex = spinner.getSelectedItemPosition();
            Comparison selectedMulti = compList.getList().get(selectedIndex);
            intent.putExtra("comparison",selectedMulti);

            startActivity(intent);
        }
    }
}