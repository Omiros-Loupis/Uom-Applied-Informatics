package com.example;
import java.util.ArrayList;
import java.util.List;
public class Brand {
    private String name;
    private List<String> mList = new ArrayList<String>();
    public Brand(String n) {
        name = n;
    }
    public boolean isBrand(String brand) {
        return name.equals(brand);
    }
    public void addModel(String model) {
        mList.add(model);
    }
    public List<String> getModels() {
        return mList;
    }
    public CarBrand(String b, String m) {
        name = b;
        models = Arrays.asList(m.split(",", -1));
        System.out.println(models);
    }
}