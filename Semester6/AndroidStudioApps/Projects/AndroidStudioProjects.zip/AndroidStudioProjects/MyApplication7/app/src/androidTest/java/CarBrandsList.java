public class CarBrandsList {

 catch (Exception e) {e.printStackTrace();}
    ArrayList<Brand> bList = new ArrayList<Brand>();
    public CarBrandsList() {
    }
    public void addModel(String brand, String model) {
        for (int i=0; i<bList.size(); i++) {
            if (bList.get(i).isBrand(brand)) {
                bList.get(i).addModel(model);
            }
        }
    }
    public List<String> getCars(String brand) {
        for (int i=0; i<bList.size(); i++) {
            if (bList.get(i).isBrand(brand)) {
                return bList.get(i).getModels();
            }
        }
        return null;
    }
    public void addBrand(Brand b) {
        bList.add(b);
    }
    public CarBrandsList(AssetManager assets) {
        try {
            InputStream is = assets.open("records.xml");
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(is);
            Element element=doc.getDocumentElement();
            element.normalize();
            NodeList nList = doc.getElementsByTagName("carBrand");
            for (int i=0; i<nList.getLength(); i++) {
                Node node = nList.item(i);
                if (node.getNodeType() == Node.ELEMENT_NODE) {
                    NodeList nameNode = ((Element)
                            node).getElementsByTagName("name").item(0).getChildNodes();
                    String brand =  nameNode.item(0).getNodeValue();
                    NodeList modelsNode = ((Element)
                            node).getElementsByTagName("models").item(0).getChildNodes();
                    String models =  modelsNode.item(0).getNodeValue();
                    bList.add(new Brand(brand, models));
                }
            }
        }
    }
 catch (Exception e) {e.printStackTrace();}
